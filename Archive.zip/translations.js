/* ============================================================
   LabourLo — translations.js
   Multilingual support: English (en), Hindi (hi), Telugu (te), Tamil (ta)
   Usage: window.LL_t(key) returns current language string
   ============================================================ */

(function () {
  'use strict';

  var LANGS = {
    en: {
      /* General */
      app_name: 'LabourLo',
      sign_in: 'Sign In',
      sign_up: 'Create Account',
      sign_in_arrow: 'Sign In →',
      create_account: 'Create Account →',
      continue_as_guest: '👤 Continue as Guest',
      logout: '🚪 Logout',
      loading: 'Loading…',
      username: 'Username',
      password: 'Password',
      confirm_password: 'Confirm Password',
      account_type: 'Account Type',
      customer: 'Customer',
      super_admin: 'Super Admin',
      book_workers: 'Book Workers',
      manage_panel: 'Manage Panel',
      join_as_worker: '🔨 Join as Worker',
      worker_portal_lbl: 'Worker',
      worker_name: 'Full Name *',
      worker_skill: 'Skill Category *',
      worker_rate: 'Hourly Rate (₹) *',
      worker_aadhar: 'Aadhar Number *',
      worker_aadhar_ph: '12-digit Aadhar number',
      worker_signup_btn: '🔨 Register as Worker →',
      skill_plumbing: '🪠 Plumbing',
      skill_electrical: '⚡ Electrical',
      skill_bricklaying: '🧱 Bricklaying',
      skill_carpentry: '🪚 Carpentry',
      skill_painting: '🎨 Painting',
      skill_labour: '🏗️ General Labour',
      skill_welding: '🔥 Welding',
      skill_cleaning: '🧹 Cleaning',
      /* Dashboard */
      dashboard: 'Dashboard',
      find_workers: '🔍 Find Workers',
      my_bookings: '📋 My Bookings',
      track_worker: '🗺️ Track Worker',
      profile: '👤 Profile',
      payments: '💳 Payments',
      book_now: '⚡ Book Now',
      customer_portal: 'Customer Portal',
      book_skilled: 'Book Skilled Workers Instantly',
      overview: 'Overview',
      total_bookings: 'Total Bookings',
      active_workers: 'Active Workers',
      revenue: 'Revenue',
      completion_rate: 'Completion Rate',
      my_bookings_count: 'My Bookings',
      completed: 'Completed',
      total_spent: 'Total Spent',
      available_professionals: 'Available Professionals',
      /* Admin */
      admin_panel: 'Admin Panel',
      admin_manage: 'Manage Workers & Bookings',
      add_labour: '➕ Add Labour Profile',
      create_labour: '➕ Create Labour Profile',
      bulk_upload: '📤 Bulk Upload (CSV)',
      pending_verify: '⏳ Pending Verification',
      verify_worker: 'Verify Worker',
      reject_worker: 'Reject',
      all_workers: '👷 All Workers',
      manage_workers: 'Manage Workers',
      full_name: 'Full Name',
      skill_category: 'Skill Category',
      hourly_rate: 'Hourly Rate',
      daily_rate: 'Daily Rate',
      rating: 'Rating',
      status: 'Status',
      actions: 'Actions',
      /* Portal */
      punch_in: '⏱ Punch In',
      punch_out: '⏹ Punch Out',
      weekly_schedule: '📅 Weekly Schedule',
      notifications: '🔔 Notifications',
      earnings: '💰 Earnings',
      verify_identity: '🆔 Verify Identity',
      aadhar_label: 'Enter 12-digit Aadhar to verify',
      verify_btn: 'Verify Now',
      verified_badge: '✅ Identity Verified',
      goals_title: '🎯 Goals & Bonuses',
      goal_rating: 'Reach 4.5+ Rating',
      goal_bookings: 'Complete 10 Bookings',
      goal_achieved: '🎉 Goal Achieved! Bonus Earned!',
      star_progress: 'Star Progress',
      upcoming_slots: '📅 Upcoming Slots',
      total_earned: 'Total Earned',
      avg_rating: 'Avg. Rating',
      worker_portal: 'Worker Portal',
      /* Stories */
      stories_label: 'Inspiring Journeys',
      stories_title: '💪 Labour Stories',
      /* Chat */
      chat_title: 'Chat with AI Assistant',
      chat_status: 'Online',
      chat_placeholder: 'Type a message…',
      chat_send: 'Send',
      /* Misc */
      welcome_back: '👋 WELCOME BACK',
      no_notifications: 'No notifications yet',
      mark_all_read: 'Mark all read',
      no_conflicts: 'No conflicts detected',
      search_placeholder: 'Search by name or skill…',
      nearest: '📍 Nearest to Me',
      top_rated: '⭐ Top Rated',
      price_low: '💰 Price: Low to High',
      details: 'Details',
      book: 'Book',
      date: 'Date',
      slot: 'Slot',
      worker: 'Worker',
      category: 'Category',
    },

    hi: {
      app_name: 'LabourLo',
      sign_in: 'साइन इन',
      sign_up: 'खाता बनाएं',
      sign_in_arrow: 'साइन इन →',
      create_account: 'खाता बनाएं →',
      continue_as_guest: '👤 अतिथि के रूप में जारी रखें',
      logout: '🚪 लॉग आउट',
      loading: 'लोड हो रहा है…',
      username: 'उपयोगकर्ता नाम',
      password: 'पासवर्ड',
      confirm_password: 'पासवर्ड की पुष्टि करें',
      account_type: 'खाता प्रकार',
      customer: 'ग्राहक',
      super_admin: 'सुपर एडमिन',
      book_workers: 'कर्मी बुक करें',
      manage_panel: 'प्रबंधन पैनल',
      join_as_worker: '🔨 कर्मी के रूप में जुड़ें',
      worker_portal_lbl: 'कर्मी',
      worker_name: 'पूरा नाम *',
      worker_skill: 'कौशल श्रेणी *',
      worker_rate: 'प्रति घंटे दर (₹) *',
      worker_aadhar: 'आधार नंबर *',
      worker_aadhar_ph: '12 अंकों का आधार नंबर',
      worker_signup_btn: '🔨 कर्मी के रूप में पंजीकरण करें →',
      skill_plumbing: '🪠 नलसाजी',
      skill_electrical: '⚡ बिजली का काम',
      skill_bricklaying: '🧱 ईंट का काम',
      skill_carpentry: '🪚 बढ़ईगीरी',
      skill_painting: '🎨 रंगाई',
      skill_labour: '🏗️ सामान्य मजदूर',
      skill_welding: '🔥 वेल्डिंग',
      skill_cleaning: '🧹 सफाई',
      dashboard: 'डैशबोर्ड',
      find_workers: '🔍 कर्मी खोजें',
      my_bookings: '📋 मेरी बुकिंग',
      track_worker: '🗺️ कर्मी ट्रैक करें',
      profile: '👤 प्रोफ़ाइल',
      payments: '💳 भुगतान',
      book_now: '⚡ अभी बुक करें',
      customer_portal: 'ग्राहक पोर्टल',
      book_skilled: 'कुशल कर्मी तुरंत बुक करें',
      overview: 'अवलोकन',
      total_bookings: 'कुल बुकिंग',
      active_workers: 'सक्रिय कर्मी',
      revenue: 'आय',
      completion_rate: 'पूर्णता दर',
      my_bookings_count: 'मेरी बुकिंग',
      completed: 'पूर्ण',
      total_spent: 'कुल खर्च',
      available_professionals: 'उपलब्ध कर्मी',
      admin_panel: 'एडमिन पैनल',
      admin_manage: 'कर्मी और बुकिंग प्रबंधन',
      add_labour: '➕ कर्मी प्रोफ़ाइल जोड़ें',
      create_labour: '➕ कर्मी प्रोफ़ाइल बनाएं',
      bulk_upload: '📤 बल्क अपलोड (CSV)',
      pending_verify: '⏳ सत्यापन के लिए लंबित',
      verify_worker: 'सत्यापित करें',
      reject_worker: 'अस्वीकार करें',
      all_workers: '👷 सभी कर्मी',
      manage_workers: 'कर्मी प्रबंधन',
      full_name: 'पूरा नाम',
      skill_category: 'कौशल श्रेणी',
      hourly_rate: 'प्रति घंटे दर',
      daily_rate: 'दैनिक दर',
      rating: 'रेटिंग',
      status: 'स्थिति',
      actions: 'कार्रवाई',
      punch_in: '⏱ पंच इन',
      punch_out: '⏹ पंच आउट',
      weekly_schedule: '📅 साप्ताहिक अनुसूची',
      notifications: '🔔 सूचनाएं',
      earnings: '💰 कमाई',
      verify_identity: '🆔 पहचान सत्यापित करें',
      aadhar_label: '12 अंकों का आधार दर्ज करें',
      verify_btn: 'अभी सत्यापित करें',
      verified_badge: '✅ पहचान सत्यापित',
      goals_title: '🎯 लक्ष्य और बोनस',
      goal_rating: '4.5+ रेटिंग प्राप्त करें',
      goal_bookings: '10 बुकिंग पूरी करें',
      goal_achieved: '🎉 लक्ष्य प्राप्त! बोनस अर्जित!',
      star_progress: 'स्टार प्रगति',
      upcoming_slots: '📅 आगामी स्लॉट',
      total_earned: 'कुल कमाई',
      avg_rating: 'औसत रेटिंग',
      worker_portal: 'कर्मी पोर्टल',
      stories_label: 'प्रेरणादायक यात्राएं',
      stories_title: '💪 श्रमिक कहानियां',
      chat_title: 'AI सहायक से बात करें',
      chat_status: 'ऑनलाइन',
      chat_placeholder: 'संदेश लिखें…',
      chat_send: 'भेजें',
      welcome_back: '👋 वापसी पर स्वागत है',
      no_notifications: 'अभी तक कोई सूचना नहीं',
      mark_all_read: 'सभी पढ़ा हुआ मार्क करें',
      no_conflicts: 'कोई विरोध नहीं पाया गया',
      search_placeholder: 'नाम या कौशल से खोजें…',
      nearest: '📍 सबसे नजदीक',
      top_rated: '⭐ शीर्ष रेटेड',
      price_low: '💰 कम कीमत पहले',
      details: 'विवरण',
      book: 'बुक करें',
      date: 'तारीख',
      slot: 'समय',
      worker: 'कर्मी',
      category: 'श्रेणी',
    },

    te: {
      app_name: 'LabourLo',
      sign_in: 'సైన్ ఇన్',
      sign_up: 'ఖాతా సృష్టించు',
      sign_in_arrow: 'సైన్ ఇన్ →',
      create_account: 'ఖాతా సృష్టించు →',
      continue_as_guest: '👤 అతిథిగా కొనసాగించు',
      logout: '🚪 లాగ్ అవుట్',
      loading: 'లోడ్ అవుతోంది…',
      username: 'వినియోగదారు పేరు',
      password: 'పాస్‌వర్డ్',
      confirm_password: 'పాస్‌వర్డ్ నిర్ధారించు',
      account_type: 'ఖాతా రకం',
      customer: 'కస్టమర్',
      super_admin: 'సూపర్ అడ్మిన్',
      book_workers: 'కార్మికులను బుక్ చేయి',
      manage_panel: 'నిర్వహణ ప్యానెల్',
      join_as_worker: '🔨 కార్మికుడిగా చేరు',
      worker_portal_lbl: 'కార్మికుడు',
      worker_name: 'పూర్తి పేరు *',
      worker_skill: 'నైపుణ్య విభాగం *',
      worker_rate: 'గంటకు ధర (₹) *',
      worker_aadhar: 'ఆధార్ నంబర్ *',
      worker_aadhar_ph: '12 అంకెల ఆధార్ నంబర్',
      worker_signup_btn: '🔨 కార్మికుడిగా నమోదు చేయి →',
      skill_plumbing: '🪠 ప్లంబింగ్',
      skill_electrical: '⚡ ఎలక్ట్రికల్',
      skill_bricklaying: '🧱 ఇటుక పని',
      skill_carpentry: '🪚 వడ్రంగి పని',
      skill_painting: '🎨 పెయింటింగ్',
      skill_labour: '🏗️ సాధారణ కార్మికుడు',
      skill_welding: '🔥 వెల్డింగ్',
      skill_cleaning: '🧹 శుభ్రపరచడం',
      dashboard: 'డ్యాష్‌బోర్డ్',
      find_workers: '🔍 కార్మికులను వెతుకు',
      my_bookings: '📋 నా బుకింగ్‌లు',
      track_worker: '🗺️ కార్మికుడిని ట్రాక్ చేయి',
      profile: '👤 ప్రొఫైల్',
      payments: '💳 చెల్లింపులు',
      book_now: '⚡ ఇప్పుడే బుక్ చేయి',
      customer_portal: 'కస్టమర్ పోర్టల్',
      book_skilled: 'నైపుణ్య కార్మికులను వెంటనే బుక్ చేయండి',
      overview: 'అవలోకనం',
      total_bookings: 'మొత్తం బుకింగ్‌లు',
      active_workers: 'యాక్టివ్ కార్మికులు',
      revenue: 'ఆదాయం',
      completion_rate: 'పూర్తి రేటు',
      my_bookings_count: 'నా బుకింగ్‌లు',
      completed: 'పూర్తయింది',
      total_spent: 'మొత్తం ఖర్చు',
      available_professionals: 'అందుబాటులో ఉన్న నిపుణులు',
      admin_panel: 'అడ్మిన్ ప్యానెల్',
      admin_manage: 'కార్మికులు & బుకింగ్‌ల నిర్వహణ',
      add_labour: '➕ కార్మిక ప్రొఫైల్ జోడించు',
      create_labour: '➕ కార్మిక ప్రొఫైల్ సృష్టించు',
      bulk_upload: '📤 బల్క్ అప్‌లోడ్ (CSV)',
      pending_verify: '⏳ ధృవీకరణ పెండింగ్',
      verify_worker: 'ధృవీకరించు',
      reject_worker: 'తిరస్కరించు',
      all_workers: '👷 అన్ని కార్మికులు',
      manage_workers: 'కార్మికుల నిర్వహణ',
      full_name: 'పూర్తి పేరు',
      skill_category: 'నైపుణ్య విభాగం',
      hourly_rate: 'గంట ధర',
      daily_rate: 'రోజువారీ ధర',
      rating: 'రేటింగ్',
      status: 'స్థితి',
      actions: 'చర్యలు',
      punch_in: '⏱ పంచ్ ఇన్',
      punch_out: '⏹ పంచ్ అవుట్',
      weekly_schedule: '📅 వారపు షెడ్యూల్',
      notifications: '🔔 నోటిఫికేషన్‌లు',
      earnings: '💰 ఆదాయం',
      verify_identity: '🆔 గుర్తింపు ధృవీకరించు',
      aadhar_label: '12 అంకెల ఆధార్ ఇవ్వండి',
      verify_btn: 'ఇప్పుడు ధృవీకరించు',
      verified_badge: '✅ గుర్తింపు ధృవీకరించబడింది',
      goals_title: '🎯 లక్ష్యాలు & బోనస్‌లు',
      goal_rating: '4.5+ రేటింగ్ సాధించు',
      goal_bookings: '10 బుకింగ్‌లు పూర్తి చేయి',
      goal_achieved: '🎉 లక్ష్యం సాధించారు! బోనస్ వచ్చింది!',
      star_progress: 'స్టార్ పురోగతి',
      upcoming_slots: '📅 రాబోయే స్లాట్‌లు',
      total_earned: 'మొత్తం ఆదాయం',
      avg_rating: 'సగటు రేటింగ్',
      worker_portal: 'కార్మిక పోర్టల్',
      stories_label: 'ప్రేరణాదాయక ప్రయాణాలు',
      stories_title: '💪 కార్మిక కథలు',
      chat_title: 'AI అసిస్టెంట్‌తో చాట్',
      chat_status: 'ఆన్‌లైన్',
      chat_placeholder: 'మెసేజ్ టైప్ చేయండి…',
      chat_send: 'పంపు',
      welcome_back: '👋 తిరిగి స్వాగతం',
      no_notifications: 'ఇంకా నోటిఫికేషన్‌లు లేవు',
      mark_all_read: 'అన్నీ చదివినట్లు గుర్తించు',
      no_conflicts: 'ఎటువంటి వైరుధ్యాలు లేవు',
      search_placeholder: 'పేరు లేదా నైపుణ్యంతో వెతుకు…',
      nearest: '📍 సమీపంలో',
      top_rated: '⭐ అత్యధిక రేటింగ్',
      price_low: '💰 తక్కువ ధర ముందు',
      details: 'వివరాలు',
      book: 'బుక్ చేయి',
      date: 'తేదీ',
      slot: 'సమయం',
      worker: 'కార్మికుడు',
      category: 'విభాగం',
    },

    ta: {
      app_name: 'LabourLo',
      sign_in: 'உள்நுழைக',
      sign_up: 'கணக்கு தொடங்கு',
      sign_in_arrow: 'உள்நுழைக →',
      create_account: 'கணக்கு தொடங்கு →',
      continue_as_guest: '👤 விருந்தினராகத் தொடரவும்',
      logout: '🚪 வெளியேறு',
      loading: 'ஏற்றுகிறது…',
      username: 'பயனர்பெயர்',
      password: 'கடவுச்சொல்',
      confirm_password: 'கடவுச்சொல்லை உறுதிப்படுத்தவும்',
      account_type: 'கணக்கு வகை',
      customer: 'வாடிக்கையாளர்',
      super_admin: 'சூப்பர் நிர்வாகி',
      book_workers: 'தொழிலாளர்களை புக் செய்',
      manage_panel: 'நிர்வாகப் பலகை',
      join_as_worker: '🔨 தொழிலாளராக சேரவும்',
      worker_portal_lbl: 'தொழிலாளர்',
      worker_name: 'முழு பெயர் *',
      worker_skill: 'திறன் பிரிவு *',
      worker_rate: 'மணிநேர கட்டணம் (₹) *',
      worker_aadhar: 'ஆதார் எண் *',
      worker_aadhar_ph: '12 இலக்க ஆதார் எண்',
      worker_signup_btn: '🔨 தொழிலாளராக பதிவுசெய் →',
      skill_plumbing: '🪠 குழாய் வேலை',
      skill_electrical: '⚡ மின் வேலை',
      skill_bricklaying: '🧱 செங்கல் போடுதல்',
      skill_carpentry: '🪚 தச்சு வேலை',
      skill_painting: '🎨 வர்ணம் பூசுதல்',
      skill_labour: '🏗️ பொது தொழிலாளி',
      skill_welding: '🔥 வெல்டிங்',
      skill_cleaning: '🧹 சுத்தம் செய்தல்',
      dashboard: 'டாஷ்போர்டு',
      find_workers: '🔍 தொழிலாளர் தேடு',
      my_bookings: '📋 என் முன்பதிவுகள்',
      track_worker: '🗺️ தொழிலாளரை கண்காணி',
      profile: '👤 சுயவிவரம்',
      payments: '💳 கட்டணங்கள்',
      book_now: '⚡ இப்போதே முன்பதிவு செய்',
      customer_portal: 'வாடிக்கையாளர் போர்ட்டல்',
      book_skilled: 'திறமையான தொழிலாளர்களை உடனடியாக புக் செய்யுங்கள்',
      overview: 'கண்ணோட்டம்',
      total_bookings: 'மொத்த முன்பதிவுகள்',
      active_workers: 'செயலில் உள்ள தொழிலாளர்கள்',
      revenue: 'வருவாய்',
      completion_rate: 'நிறைவு விகிதம்',
      my_bookings_count: 'என் முன்பதிவுகள்',
      completed: 'நிறைவடைந்தது',
      total_spent: 'மொத்த செலவு',
      available_professionals: 'கிடைக்கும் நிபுணர்கள்',
      admin_panel: 'நிர்வாகப் பலகை',
      admin_manage: 'தொழிலாளர் & முன்பதிவு மேலாண்மை',
      add_labour: '➕ தொழிலாளர் சுயவிவரம் சேர்',
      create_labour: '➕ தொழிலாளர் சுயவிவரம் உருவாக்கு',
      bulk_upload: '📤 மொத்த பதிவேற்றம் (CSV)',
      pending_verify: '⏳ சரிபார்ப்புக்காக காத்திருக்கிறது',
      verify_worker: 'சரிபார்க்கவும்',
      reject_worker: 'நிராகரி',
      all_workers: '👷 எல்லா தொழிலாளர்களும்',
      manage_workers: 'தொழிலாளர் மேலாண்மை',
      full_name: 'முழு பெயர்',
      skill_category: 'திறன் பிரிவு',
      hourly_rate: 'மணிநேர கட்டணம்',
      daily_rate: 'தினசரி கட்டணம்',
      rating: 'மதிப்பீடு',
      status: 'நிலை',
      actions: 'செயல்கள்',
      punch_in: '⏱ நுழைவு',
      punch_out: '⏹ வெளியேற்றம்',
      weekly_schedule: '📅 வாராந்திர அட்டவணை',
      notifications: '🔔 அறிவிப்புகள்',
      earnings: '💰 வருவாய்',
      verify_identity: '🆔 அடையாளத்தை சரிபார்',
      aadhar_label: '12 இலக்க ஆதார் உள்ளிடவும்',
      verify_btn: 'இப்போது சரிபார்',
      verified_badge: '✅ அடையாளம் சரிபார்க்கப்பட்டது',
      goals_title: '🎯 இலக்குகளும் போனஸும்',
      goal_rating: '4.5+ மதிப்பீடு பெறவும்',
      goal_bookings: '10 முன்பதிவுகளை முடிக்கவும்',
      goal_achieved: '🎉 இலக்கு அடைந்தது! போனஸ் கிடைத்தது!',
      star_progress: 'நட்சத்திர முன்னேற்றம்',
      upcoming_slots: '📅 வரவிருக்கும் நேரங்கள்',
      total_earned: 'மொத்த வருவாய்',
      avg_rating: 'சராசரி மதிப்பீடு',
      worker_portal: 'தொழிலாளர் போர்ட்டல்',
      stories_label: 'ஊக்கமளிக்கும் பயணங்கள்',
      stories_title: '💪 தொழிலாளர் கதைகள்',
      chat_title: 'AI உதவியாளருடன் அரட்டை',
      chat_status: 'ஆன்லைன்',
      chat_placeholder: 'செய்தி தட்டச்சு செய்யவும்…',
      chat_send: 'அனுப்பு',
      welcome_back: '👋 மீண்டும் வருக',
      no_notifications: 'இன்னும் அறிவிப்புகள் இல்லை',
      mark_all_read: 'அனைத்தையும் படித்தது எனக் குறி',
      no_conflicts: 'எந்த முரண்பாடும் கண்டுபிடிக்கப்படவில்லை',
      search_placeholder: 'பெயர் அல்லது திறனால் தேடவும்…',
      nearest: '📍 மிக அருகில்',
      top_rated: '⭐ சிறந்த மதிப்பீடு',
      price_low: '💰 குறைந்த விலை முதல்',
      details: 'விவரங்கள்',
      book: 'புக் செய்',
      date: 'தேதி',
      slot: 'நேரம்',
      worker: 'தொழிலாளர்',
      category: 'பிரிவு',
    }
  };

  var currentLang = localStorage.getItem('ll_lang') || 'en';

  function t(key) {
    var lang = LANGS[currentLang] || LANGS['en'];
    return lang[key] || LANGS['en'][key] || key;
  }

  function setLang(lang) {
    if (!LANGS[lang]) return;
    currentLang = lang;
    localStorage.setItem('ll_lang', lang);
    applyTranslations();
  }

  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var key = el.getAttribute('data-i18n');
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = t(key);
      } else {
        el.textContent = t(key);
      }
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function (el) {
      el.innerHTML = t(el.getAttribute('data-i18n-html'));
    });
    // Update lang switcher active state
    document.querySelectorAll('.ll-lang-btn').forEach(function (btn) {
      btn.classList.toggle('active', btn.dataset.lang === currentLang);
    });
    // Fire event so page-level scripts can react
    document.dispatchEvent(new CustomEvent('ll:langchange', { detail: { lang: currentLang } }));
  }

  /* ── Language Switcher Widget ── */
  function injectLangSwitcher() {
    if (document.getElementById('ll-lang-switcher')) return;
    var widget = document.createElement('div');
    widget.id = 'll-lang-switcher';
    widget.innerHTML =
      '<button id="ll-lang-toggle" title="Change Language" aria-label="Language switcher">🌍</button>'
      + '<div class="ll-lang-menu" id="ll-lang-menu">'
      + ['en','hi','te','ta'].map(function(l) {
          var labels = { en:'🇬🇧 EN', hi:'🇮🇳 हि', te:'🇮🇳 తె', ta:'🇮🇳 த' };
          return '<button class="ll-lang-btn" data-lang="'+l+'">'+labels[l]+'</button>';
        }).join('')
      + '</div>';

    var style = document.createElement('style');
    style.textContent = [
      '#ll-lang-switcher{position:fixed;bottom:80px;right:24px;z-index:8000;display:flex;flex-direction:column;align-items:flex-end;gap:8px}',
      '#ll-lang-toggle{width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#FF8C00,#00D4D0);border:none;font-size:22px;cursor:pointer;box-shadow:0 4px 20px rgba(255,140,0,0.4);transition:transform .2s;display:flex;align-items:center;justify-content:center}',
      '#ll-lang-toggle:hover{transform:scale(1.12) rotate(15deg)}',
      '.ll-lang-menu{display:none;flex-direction:column;gap:4px;background:#ffffff;border:1px solid rgba(0,0,0,0.08);border-radius:12px;padding:8px;backdrop-filter:blur(16px);box-shadow:0 8px 32px rgba(0,0,0,0.12)}',
      '.ll-lang-menu.open{display:flex}',
      '.ll-lang-btn{padding:8px 14px;border:none;border-radius:8px;background:transparent;color:#5a6478;font-size:13px;font-weight:600;cursor:pointer;text-align:left;transition:all .15s;font-family:inherit}',
      '.ll-lang-btn:hover,.ll-lang-btn.active{background:rgba(255,140,0,.12);color:#FF8C00}'
    ].join('');
    document.head.appendChild(style);
    document.body.appendChild(widget);

    widget.querySelector('#ll-lang-toggle').addEventListener('click', function (e) {
      e.stopPropagation();
      document.getElementById('ll-lang-menu').classList.toggle('open');
    });
    document.addEventListener('click', function () {
      var m = document.getElementById('ll-lang-menu');
      if (m) m.classList.remove('open');
    });
    widget.querySelectorAll('.ll-lang-btn').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        setLang(btn.dataset.lang);
        document.getElementById('ll-lang-menu').classList.remove('open');
      });
    });
  }

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      injectLangSwitcher();
      applyTranslations();
    });
  } else {
    injectLangSwitcher();
    applyTranslations();
  }

  // Expose
  window.LL_t       = t;
  window.LL_setLang = setLang;
  window.LL_langs   = LANGS;
})();
